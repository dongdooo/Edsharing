<!-- Start of Features Boxes -->
	<section id="ngo_features" class="mbtm">
		<section class="container-fluid container">
		<section class="row-fluid">
			<!-- Start of Features Box 1 -->
			<figure class="span3 feature">
			<div class="ftr_img f-img-1"> 
				<span class="img"> House of Talents</span>
			</div>
			<div class="ftr_txt">
			<strong> House of Talents </strong>
			<p> We raise our society and crack the eggs of talents all over the country and the world in the next phase. </p>
			</div>
		</figure>
			<!-- End of Features Boxes 1 -->
			
			<!-- Start of Features Box 2 -->
			<figure class="span3 feature">
			<div class="ftr_img f-img-2"> 
				<span class="img"> Volcanic Students </span>
			</div>
			<div class="ftr_txt">
			<strong> Volcanic Students </strong>
			<p> We believe that in anywhere, there must be talents all over the places. So it can be you. Show me the best of you. </p>
			</div>
		</figure>
			<!-- End of Features Boxes 2 -->
			
			<!-- Start of Features Box 3 --> 
			<figure class="span3 feature">
			<div class="ftr_img f-img-3"> 
				<span class="img"> Talent Storms  </span>
			</div>
			<div class="ftr_txt">
			<strong> Talent Storms </strong>
			<p> And once the storm is over you won't remember how you made it through how you managed to survive.  </p>
			</div>
		</figure>
			<!-- End of Features Boxes 3 -->
			
			<!-- Start of Features Box 4 -->		
			<figure class="span3 feature">
			<div class="ftr_img f-img-4"> 
				<span class="img"> Top Tier Wave </span>
			</div>
			<div class="ftr_txt">
			<strong> Top Tier Wave </strong>
			<p> Opportunity does not come often, so do not miss it when it lead to you. While you are young, make the best of you since today. </p>
			</div>
		</figure>
 			<!-- End of Features Boxes 4 -->
	</section>
	</section>
	</section>
<!-- End of Features Boxes -->