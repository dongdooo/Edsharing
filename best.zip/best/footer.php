<!-- Start of Footer -->
	<footer id="footer" class="mtp">
	
	<!-- Start of Footer 1 -->
		<section class="footer_1">
		<section class="container-fluid container">
			<section class="row-fluid">
					<section id="banner" class="span12 first"> 
										<div class="inner"> 
											<div class="span9">
											<h2> Free gift and reward for all talents </h2>
											<h3> * Do not think alone, let's us know who you are. </h3>
											</div>
											<div class="pull-left span3">
											<div id="banner_rounded" class="img-circle">
											<h3>	JOIN US NOW FOR FREE, DO NOT WAIT<span> </span> </h3> </div>
											</div>
										</div>
								</section>
				
				<section class="span12 first" id="footer_main">
					
					<section class="span3 first widget">
						<h4>GET IN <span> Touch </span> <span class="h-line"></span> </h4>
						
						<form id="contact_form" method="post" action="contact.php">
								
									<input type="text" value="Name"  name="name" required/>
									<input type="email" value="Email" name="email" required />
									<textarea rows="5" cols="20" name="comments" required>Comments</textarea>
									<input type="submit" name="submit" value="Send Message" />
						</form>
						
						</section>
					<section class="span3 widget popular_post"> 
					<h4>Blog Popular <span> Post </span> <span class="h-line"></span> </h4>
					<ul id="popular_post">
						<li> <span> <i class="icon-facetime-video"></i> </span> <p> Talent Kids of the year	 </p></li>			
						<li> <span> <i class="icon-volume-up"></i></span> <p> <a href="#"> Why not study in Thailand?	</a> </p></li>			
						<li> <span> <i class="icon-picture"></i> </span> <p> Goinng aboard really worth?	 </p></li>			
						<li> <span> <i class="icon-volume-up"></i> </span> <p> How to have better life while studying </p></li>	
					</ul>
					<a class="v-a" href="#">+ View All <span class="h-line"></span></a>
					</section>
					<section class="widget span3"> 
						
						<h4>Latest Twitter <span> Updates </span> <span class="h-line"></span> </h4>
						<ul id="tweets_crunchpress">
							<li> Congrat! to Ms.Kanokporn winner of Maths from Assumption School<span>  </span> <span> - 2 hour ago </span> </li>
							<li> Congrat! to Ms.Pornpun winner of Athletes from Assumption School <span>  </span> <span> -1 Day ago </span> </li>
						</ul>
						<a class="v-a" href="#">+ View All <span class="h-line"></span></a>
						</section>
					<section class="span3 widget">
						<h4>LATEST EVENTS <span> GALLERY </span> <span class="h-line"></span> </h4>
								<ul class="gallery-list gallery_widget">
										<li class="view_new view-tenth">
										<img class="galler-img" src="http://c953364.r64.cf2.rackcdn.com/images/247721/featured_small/crowd.jpg?1450053841" alt="">
										<div class="mask">
										<a class="image-gal info" rel="prettyPhoto[gallery1]" href="images/t_slider_3.jpg" title="">&nbsp;</a>
										</div>
										</li>
										<li class="view_new view-tenth">
										<img class="galler-img" src="http://c953364.r64.cf2.rackcdn.com/images/247721/featured_small/crowd.jpg?1450053841" alt="">
										<div class="mask">
										<a class="image-gal info" rel="prettyPhoto[gallery1]" href="images/t_slider_5.jpg" title="">&nbsp;</a>
										</div>
										</li>
										<li class="view_new view-tenth">
										<img class="galler-img" src="http://c953364.r64.cf2.rackcdn.com/images/247721/featured_small/crowd.jpg?1450053841" alt="">
										<div class="mask">
										<a class="image-gal info" rel="prettyPhoto[gallery1]" href="images/t_slider_2.jpg" title="">&nbsp;</a>
										</div>
										</li>
										<li class="view_new view-tenth">
										<img class="galler-img" src="http://c953364.r64.cf2.rackcdn.com/images/247721/featured_small/crowd.jpg?1450053841" alt="">
										<div class="mask">
										<a class="image-gal info" rel="prettyPhoto[gallery1]" href="images/t_slider_4.jpg" title="">&nbsp;</a>
										</div>
										</li>
				
										<li class="view_new view-tenth">
										<img class="galler-img" src="http://c953364.r64.cf2.rackcdn.com/images/247721/featured_small/crowd.jpg?1450053841" alt="">
										<div class="mask">
										<a class="image-gal info" rel="prettyPhoto[gallery1]" href="images/t_slider_2.jpg" title="">&nbsp;</a>
										</div>
										</li>
										<li class="view_new view-tenth">
										<img class="galler-img" src="http://c953364.r64.cf2.rackcdn.com/images/247721/featured_small/crowd.jpg?1450053841" alt="">
										<div class="mask">
										<a class="image-gal info" rel="prettyPhoto[gallery1]" href="images/t_slider_4.jpg" title="">&nbsp;</a>
										</div>
										</li>
										<li class="view_new view-tenth">
										<img class="galler-img" src="http://c953364.r64.cf2.rackcdn.com/images/247721/featured_small/crowd.jpg?1450053841" alt="">
										<div class="mask">
										<a class="image-gal info" rel="prettyPhoto[gallery1]" href="images/t_slider_5.jpg" title="">&nbsp;</a>
										</div>
										</li>
										<li class="view_new view-tenth">
										<img class="galler-img" src="http://c953364.r64.cf2.rackcdn.com/images/247721/featured_small/crowd.jpg?1450053841" alt="">
										<div class="mask">
										<a class="image-gal info" rel="prettyPhoto[gallery1]" href="images/t_slider_3.jpg" title="">&nbsp;</a>
										</div>
										</li>
																	
				

										<li class="view_new view-tenth">
										<img class="galler-img" src="http://c953364.r64.cf2.rackcdn.com/images/247721/featured_small/crowd.jpg?1450053841" alt="">
										<div class="mask">
										<a class="image-gal info" rel="prettyPhoto[gallery1]" href="images/t_slider_5.jpg" title="">&nbsp;</a>
										</div>
										</li>
										<li class="view_new view-tenth">
										<img class="galler-img" src="http://c953364.r64.cf2.rackcdn.com/images/247721/featured_small/crowd.jpg?1450053841" alt="">
										<div class="mask">
										<a class="image-gal info" rel="prettyPhoto[gallery1]" href="images/t_slider_3.jpg" title="">&nbsp;</a>
										</div>
										</li>
										<li class="view_new view-tenth">
										<img class="galler-img" src="http://c953364.r64.cf2.rackcdn.com/images/247721/featured_small/crowd.jpg?1450053841" alt="">
										<div class="mask">
										<a class="image-gal info" rel="prettyPhoto[gallery1]" href="images/t_slider_2.jpg" title="">&nbsp;</a>
										</div>
										</li>
										<li class="view_new view-tenth">
										<img class="galler-img" src="http://c953364.r64.cf2.rackcdn.com/images/247721/featured_small/crowd.jpg?1450053841" alt="">
										<div class="mask">
										<a class="image-gal info" rel="prettyPhoto[gallery1]" href="images/t_slider_4.jpg" title="">&nbsp;</a>
										</div>
										</li>
								</ul>
					
					<a class="v-a" href="#">+ View All <span class="h-line"></span></a>
						</section>
					</section>
			</section>
		</section>
	</section>
	<!-- End of Footer 1 -->
	
	<!-- Start of Footer 2 -->
		<section class="footer_2">
		<section class="container-fluid container">
			<section class="row-fluid">
						<figure class="span6" id="footer_left">  <i class="icon-mobile-phone"></i> <span> +66 82 888 6624 </span> <i class="icon-envelope-alt"></i> <span> contact@bebest.cf  </span>  </figure>
						<figure class="span6" id="footer_right">
						<div id="socialicons"> 
 							<a data-placement="top" rel="tooltip" title="Join us on Facebook" id="social_facebook" class="social_active" href="#" >		<span>	</span></a> 
							<a data-placement="top" rel="tooltip" title="Follow us on Twitter" id="social_twitter" class="social_active" href="#"  >	<span>	</span></a> 
							<a data-placement="top" rel="tooltip" title="Visit LinkedIn Page" id="social_linkedin" class="social_active" href="#"  >	<span>	</span></a> 
							<a data-placement="top" rel="tooltip" title="Browse Flicker Gallery" id="social_flickr" class="social_active" href="#" >	<span>	</span></a> 
							<a data-placement="top" rel="tooltip" title="Check us on Forst " id="social_forst" class="social_active" href="#"  >		<span>	</span></a> 
							<a data-placement="top" rel="tooltip" title="View Viemeo Video Collection" id="social_vimeo" class="social_active" >		<span>	</span></a> 
							<a data-placement="top" rel="tooltip" title="Pin Us" id="social_pinterest" class="social_active" href="#" >					<span></span>	</a> 
							<a data-placement="top" rel="tooltip" title="Join our Social Circle" id="social_google_plus" class="social_active"  >		<span>	</span></a> 
							<a data-placement="top" rel="tooltip" title="Watch Our Broadcasting" id="social_youtube" class="social_active" href="#">	<span>	</span></a> 
						</div>
						</figure>
 
			</section>
		</section>
	</section>
	<!-- End of Footer 2 -->
	
	<!-- Start of Footer 3 -->
		<section class="footer_3">
		<section class="container-fluid container">
			<section class="row-fluid">
			
			<figure class="span6" id="footer_left">

				<ul class="footer_nav"> 
				<li> <a href="index.php">	Home 		</a> </li>
				<li> <a href="feature.php"> 	Features	</a> </li>
				<li> <a href="#"> 	Blog 		</a> </li>
				<li> <a href="listing.php"> 	Portfolio	</a> </li>
				<li> <a href="contact_us.php"> 	Contact		</a> </li>
				</ul>
				<p> Copyright © 2016 - BeBest by <a href="http://www.bebest.cf"> bebest.ml </a></p>
				
				</figure>
			
			<figure class="span6" id="footer_right">

					

			</figure>
			</section>
		</section>
	</section>
	<!-- End of Footer 3 -->
	
	</footer>
<!-- End of Footer -->