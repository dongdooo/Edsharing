<?php require('head.php');?>

<body>
<!-- Start Main Wrapper -->
<div class="wrapper">
<?php require('header.php');?>

<!-- Title & BreadCrumbs -->
<section class="mtop">
	<section class="container-fluid container">
		<section class="row-fluid">
			<section id="donation_box">
				<section class="container container-fluid">
				<section class="row-fluid">
			<div class="span8 first"> <h2> 1st Top Score in Maths 01/2016 </h2> </div>
			<div class="span4 title_right">
				<div class="dropdown" id="cart_dropdown">
 				<a data-toggle="dropdown" class="dropdown-toggle" role="button" id="cart_down" href="#">
				<i class="icon-ticket"></i>
				Charity Projects
				<span class="caret"></span>
				</a>
				
						<div class="dropdown-menu" aria-labelledby="cart_down" role="menu" id="listing_dropdown">
								<ul>
									<li> Charity Events <a href="#"> 2 </a> </li>
									<li> Fundraising <a href="#"> 9 </a> </li>
									<li> Non-Profit <a href="#"> 2 </a> </li>
								</ul>
						</div>
					</div>
			</div>
		</section>
			</section>
			</section>		<!-- end of Page Title -->
	</section>
 		<section class="row-fluid">
			<!-- BreadCrumbs -->
				<figure id="breadcrumbs" class="span12">
					<ul class="breadcrumb">
					<li><a href="#">Home</a> <span class="divider">/</span></li>
					<li class="active">Event Detail </li>
					</ul>
				</figure>
			<!-- End of breadcrumbs -->
		</section>
	</section>
</section>
<!-- End of Tile & Breadcrumbs -->

<!-- Page Content Container -->
<section id="content" class="mbtm fund_rasising_listing">
	<section class="container-fluid container">
	
		<section class="row-fluid">
			
			<section class="span9 fund_project_detail" id="fund_project_detail">  
					
					<figure class="span12 first outer_lyr" id="category_image"> 
						
						<img src="images/01.jpg" alt="Crowd Funding" />

					<figure class="span12 first fund_project" id="charity_progress">
 							
					<div class="span12 first">
						<span class="current_collection">   </span>
						
						<h4>  </h4>
						
						<div class="progress progress-striped active">  
								<div class="bar p80"></div>    
						</div>
						 
						 <div class="info"> 
									<div class="span3 first">
										<i class="icon-user"></i> <span> 39 </span> Pledgers
									</div>
									
									<div class="span4 first">
									<i class="icon-fullscreen"></i> <span> Pledged of ฿20,000 Goal </span> 
									</div>
									
									<div class="span2 first">
										 <i class="icon-dashboard"></i>  <span> $9,721 </span>  
									</div>
									
									<div class="span3" id="dayz">
										<i class="icon-calendar-empty"></i> <span> 74 </span> Days Left
									</div>
									
							  </div>
						
						</div>							
						
					</figure>
				
					</figure>
			
					<figure class="span12 first outer_lyr" id="project_contet">
					
							<div class="inner_lyr">
							<h3> Outstanding Maths Score Surprised </h3>
							<p>Kanokporn is a student at Wat Phar Sang School from Bangkok. An honors student from Maths, she hopes to one day become a pediatrician. Growing up with parents who work in agriculture, she was often responsible for taking care of her three younger siblings, so she loves working with children, and wants to build a career on keeping them healthy. She also volunteers at her community daycare in between taking care of her siblings and studying for entrance exams.</p>
 
							<p>Her top choice university is Chulalongkorn University, where she hopes to study as part of the Faculty of Allied Health Sciences. However, with her family’s agricultural income, they cannot afford to send her to university while maintaining their current living situation. Join us in helping Kanokporn attain a university education and her dream of becoming a doctor. Every contribution, even friendship and words of encouragement can make an impact.</p>


							
							</div>
					</figure>
					
					<figure class="span12 first">
							<a href="#" class="tier_button"> BeBest Donation Tiers </a>
							<ul  id="tiers">

							<li><span class="span3 first">  <strong>  Tier 1 </strong> : ฿100 to 5,000 </span> <span class="span8"> Every little bit counts. You will receive a personal thank you from the student you have sponsored.
							<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
							<input type="hidden" name="cmd" value="_s-xclick">
							<input type="hidden" name="hosted_button_id" value="7RTMG623YLUWJ">
							<input type="image" src="https://www.paypalobjects.com/en_US/GB/i/btn/btn_donateCC_LG.gif" style="float:right;" border="0" name="submit" alt="PayPal – The safer, easier way to pay online!">

							</form>
							</span> 
							</li>

								<li> 	<span class="span3 first">  <strong> Tier 2 </strong> : ฿5,001 to 20,000 </span> <span class="span8"> There are friends and then there are best friends. You wil receive a personal thank you as well as an acknowledgement on this student's profile page.		<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
							<input type="hidden" name="cmd" value="_s-xclick">
							<input type="hidden" name="hosted_button_id" value="7RTMG623YLUWJ">
							<input type="image" src="https://www.paypalobjects.com/en_US/GB/i/btn/btn_donateCC_LG.gif" style="float:right;" border="0" name="submit" alt="PayPal – The safer, easier way to pay online!"></span> </li>
								<li> 	<span class="span3 first">  <strong> Tier 3 </strong> : More than ฿20,001 </span> <span class="span8">Helping to change the educational world, one student at a time. You will be acknowledged on our homepage and the student will receive a certificate of your endorsement. A banner of your sponsorship will be displayed on the student's profile page. <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
							<input type="hidden" name="cmd" value="_s-xclick">
							<input type="hidden" name="hosted_button_id" value="7RTMG623YLUWJ">
							<input type="image" src="https://www.paypalobjects.com/en_US/GB/i/btn/btn_donateCC_LG.gif" style="float:right;" border="0" name="submit" alt="PayPal – The safer, easier way to pay online!"> </span> </li>
								
							</ul>
							
					</figure>
			</section>
				
				
<?php require('sidebar.php');?>	
 
		</section>
	</section>

</section>
<!-- Page Content Container -->
	 
<?php require('footer.php');?>
</div>
<!-- End Main Wrapper -->
<!-- JS Files Start -->
<script type="text/javascript" src="js/lib-1-9-1.js"></script><!-- lib Js -->
<script type="text/javascript" src="js/lib-1-7-1.js"></script><!-- lib Js -->
<script type="text/javascript" src="js/modernizr.js"></script><!-- Modernizr -->
<script type="text/javascript" src="js/easing.js"></script><!-- Easing js -->
<script type="text/javascript" src="js/bootstrap.js"></script><!-- Bootstrap -->
<script type="text/javascript" src="js/bxslider.js"></script><!-- BX Slider -->
<script type="text/javascript" src="js/clearInput.js"></script><!-- Input Clear -->
<script type="text/javascript" src="js/smooth-scroll.js"></script><!-- smooth Scroll -->
<script type="text/javascript" src="js/prettyPhoto.js"></script><!-- Pretty Photo -->
<script type="text/javascript" src="js/social.js"></script><!-- Social Media Hover Effect -->
<script type="text/javascript" src="js/countdown.js"></script><!-- Event Counter -->
<script type="text/javascript" src="js/custom.js"></script><!-- Custom / Functions -->
<!--[if IE 8]>
     <script src="js/ie8_fix_maxwidth.js" type="text/javascript"></script>
<![endif]-->
</body>
</html>
