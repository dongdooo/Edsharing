<?php require('head.php');?>
<body>
<!-- Start Main Wrapper -->
<div class="wrapper">

<?php require_once('header.php');?>

<?php require_once('banner.php');?>

<?php require_once('feature.php');?>

<!-- Start of Donation Box -->
	<section id="donation_box" class="mbtm">
	<section class="container container-fluid">
		<section class="row-fluid">
		<figure class="span10">
			<h2> Sometimes it takes a <strong> social investors</strong> to raise up a <strong> social talents!</strong> </h2>
		</figure>
		<figure class="span2">
			<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
		<input type="hidden" name="cmd" value="_s-xclick">
		<input type="hidden" name="hosted_button_id" value="7RTMG623YLUWJ">
		<input type="image" src="https://www.paypalobjects.com/en_US/GB/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal – The safer, easier way to pay online!">

		</form>

<!-- 
			<form action="detail.php">
				<input type="hidden" value="5.00" name="amout" />
				<input type="hidden" value="USD" name="Currency" />
				<button  data-placement="top" rel="tooltip" title="Support Us"  class=" btn btn-large dropdown-toggle" type="submit">Donate Now</button>
			</form>  -->
		</figure>
		</section>
	</section>
</section>
<!-- End of Donation Box -->

<!-- Start of Charity News & Progress Section -->
	<section id="progress_news" class="mbtm">
		<section class="container-fluid container">
			<section class="row-fluid">
			
				<figure class="span6 first" id="charity_progress">
					<h3> Ms.Kanokporn Karasin </h3>
					<div id="charity_process_inner">
						<div class="span5 img first">
							<img src="images/01copy.jpg" />
						</div>
						<div class="span7 progress_report">
						<h2> ฿18,387 </h2>
						<h4> 1st Top Score in Maths 01/2016</h4>
						<h4> Pledged of ฿20,000 Goal</h4>
						      <div class="progress progress-striped active m9p">  
									<div class="bar p80"></div>  
							  </div>  
							  <br />
							  <div class="info"> 
									<div class="span6 first">
										<i class="icon-user"></i> <span> 47 </span> Pledgers
									</div>
									
									<div class="span6 ntr">
										<i class="icon-calendar-empty"></i> <span> 204 </span> Days Left
									</div>
									
							  </div>
							  
						</div>
					</div>
				</figure>
				<figure class="span6" id="charity_progress">
					<h3>  Ms.Jaruwan Chaluay </h3>
					<div id="charity_process_inner">
						<div class="span5 img first">
							<img src="images/02copy.jpg" />
						</div>
						<div class="span7 progress_report">
						<h2> ฿15,668 </h2>
						<h4> 1st Top Score in English 01/2016</h4>
						<h4> Pledged of ฿20,000 Goal</h4>
						      <div class="progress progress-striped active m9p">  
									<div class="bar p80"></div>  
							  </div>  
							  <br />
							  <div class="info"> 
									<div class="span6 first">
										<i class="icon-user"></i> <span> 37 </span> Pledgers
									</div>
									
									<div class="span6 ntr">
										<i class="icon-calendar-empty"></i> <span> 154 </span> Days Left
									</div>
									
							  </div>
							  
						</div>
					</div>
				</figure>

				
			</section>
		</section>
	</section>
<!-- End of Charity News & Progress Section -->

<!-- Start of Event & Videos -->
	<section id="events_videos" class="mbtm">
		<section class="container-fluid container">
			<section class="row-fluid">
			
			<figure class="span6 first" id="video_slider">
			<h2> Helps Be Best Students <span> Events & Videos </span> </h2>
				<div class="video_slider_container span8 offset2">
					<ul class="video_slider">
						<li> 
							<div class="video">
							<iframe src="http://www.youtube.com/embed/kpW6ZPeYfwc?autoplay=0" width="376" height="230" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>
							<div class="tag_line"> Kanittha won fourth gold at Queen swimming sports students .</div>
							</div>
						</li>
					</ul>
				</div>
			</figure>
			
			<figure class="span5" id="news_accordion">
			    <div class="accordion" id="accordion_news">
						<div class="accordion-group">
							<div class="accordion-heading">
							<a class="accordion-toggle active" data-toggle="collapse" data-parent="#accordion_news" href="#co">
								<span class="datem span3 first"> 05/22 </span>
								<span class="title span8"> Math Marathon 2016 
									<span class="location_date"> 
											<span class="location">	<i class="icon-map-marker"></i> Bangkok </span>
											<span class="date"> 	<i class="icon-time"></i>		May22, 2016	 </span>
									</span>
								</span>
								<span class="span1" id="icon_toggle"> <i class="icon-minus"> </i></span>	
							</a>
							</div>
							
							<div id="co" class="accordion-body collapse in">
							<div class="accordion-inner">
								<figure class="span3 img first">
									<img src="http://www.iquestaustin.com/uploads/1/7/6/1/17614643/3069044_orig.png?100" alt="" />
								</figure>
								<figure class="span9">
								<p> Math Marathon 2016 alorum prompta, mel ea sumo semper nusquam. Soluta intellegebat vim id, vix timeam latine electram at. </p>
								<a href="#"> Read More</a>
								</figure>
							</div>
							</div>
						</div>
						<div class="accordion-group">
							<div class="accordion-heading">
							<a class="accordion-toggle inactive" data-toggle="collapse" data-parent="#accordion_news" href="#c2">
								<span class="datem span3 first"> 05/27 </span>
								<span class="title span8"> Kids Fun Gala 
									<span class="location_date"> 
											<span class="location">	<i class="icon-map-marker"></i> Bangkok </span>
											<span class="date"> 	<i class="icon-time"></i>		May 27, 2016	 </span>
									</span>
								</span>
								<span class="span1" id="icon_toggle"> <i class="icon-plus"> </i></span>	
							</a>
							</div>
							
							<div id="c2" class="accordion-body collapse">
							<div class="accordion-inner">
								<figure class="span3 img first">
									<img src="https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSqninHeh6DUnHwn3xMrzFwf2qP21_p1EDpSFVeP9DOVI93cinKyA" alt="" />
								</figure>
								<figure class="span9">
								<p> Kid Fun Gala 2016 alorum prompta, mel ea sumo semper nusquam. Soluta intellegebat vim id, vix timeam latine electram at. </p>
								<a href="#"> Read More</a>
								</figure>
							</div>
							</div>
						</div>
						<div class="accordion-group">
							<div class="accordion-heading">
							<a class="accordion-toggle inactive" data-toggle="collapse" data-parent="#accordion_news" href="#c3">
								<span class="datem span3 first"> 05/29 </span>
								<span class="title span8"> Family Festival 
									<span class="location_date"> 
											<span class="location">	<i class="icon-map-marker"></i> Bangkok </span>
											<span class="date"> 	<i class="icon-time"></i>		May 29, 2016	 </span>
									</span>
								</span>
								<span class="span1" id="icon_toggle"> <i class="icon-plus"> </i></span>	
							</a>
							</div>
							
							<div id="c3" class="accordion-body collapse">
							<div class="accordion-inner">
								<figure class="span3 img first">
									<img src="http://i.dailymail.co.uk/i/pix/2011/06/03/article-1394047-0C4CB16C00000578-518_634x479.jpg" alt="" />
								</figure>
								<figure class="span9">
								<p> Family Festival 2016 alorum prompta, mel ea sumo semper nusquam. Soluta intellegebat vim id, vix timeam latine electram at. </p>
								<a href="#"> Read More</a>
								</figure>
							</div>
							</div>
						</div>
 
						
				</div>
			</figure>
			
			</section>
		</section>
</section>
<!-- End Of Event & Videos -->



<?php require_once('footer.php');?>

</div>
<!-- End Main Wrapper -->
<!-- JS Files Start -->
<script type="text/javascript" src="js/lib-1-9-1.js"></script><!-- lib Js -->
<script type="text/javascript" src="js/lib-1-7-1.js"></script><!-- lib Js -->
<script type="text/javascript" src="js/modernizr.js"></script><!-- Modernizr -->
<script type="text/javascript" src="js/easing.js"></script><!-- Easing js -->
<script type="text/javascript" src="js/bootstrap.js"></script><!-- Bootstrap -->
<script type="text/javascript" src="js/bxslider.js"></script><!-- BX Slider -->
<script type="text/javascript" src="js/fitvids.js"></script><!-- fIt Video -->
<script type="text/javascript" src="js/clearInput.js"></script><!-- Input Clear -->
<script type="text/javascript" src="js/smooth-scroll.js"></script><!-- smooth Scroll -->
<script type="text/javascript" src="js/prettyPhoto.js"></script><!-- Pretty Photo -->
<script type="text/javascript" src="js/social.js"></script><!-- Social Media Hover Effect -->
<script type="text/javascript" src="js/countdown.js"></script><!-- Event Counter -->

<script type="text/javascript" src="js/custom.js"></script><!-- Custom / Functions -->
<!--[if IE 8]>
     <script src="js/ie8_fix_maxwidth.js" type="text/javascript"></script>
<![endif]-->
</body>
</html>