<!-- Start of Header Banner -->
	<section class="banner_slider mbtm">
		 <ul id="banner_slider">
					
					<li> 
						<img src="images/student1.jpg" alt="Banner Slider"/>
							<div class="slider_content"> 
								<p class="b_dark"> we need your support</p>
								<span class="clear"></span>
								<p class="b_green"> to educate and enrich talented youth!</p>
							</div> 
					</li>
					
					<li> 
						<img src="images/student4.jpg" alt="Banner Slider" />
							<div class="slider_content"> 
								<p class="b_dark"> we need your support</p>
								<span class="clear"></span>
								<p class="b_green"> to educate and enrich talented youth!</p>
							</div> 
					</li>
										<li> 
						<img src="images/student3.jpg" alt="Banner Slider" />
							<div class="slider_content"> 
								<p class="b_dark"> we need your support</p>
								<span class="clear"></span>
								<p class="b_green"> to educate and enrich talented youth!</p>
							</div> 
					</li>
					<li> 
						<img src="images/student6.jpg" alt="Banner Slider" />
							<div class="slider_content"> 
								<p class="b_dark"> we need your support</p>
								<span class="clear"></span>
								<p class="b_green"> to educate and enrich talented youth!</p>
							</div> 
					</li>
					<li> 
						<img src="images/student5.jpg" alt="Banner Slider" />
							<div class="slider_content"> 
								<p class="b_dark"> we need your support</p>
								<span class="clear"></span>
								<p class="b_green"> to educate and enrich talented youth!</p>
							</div> 
					</li>
		 
		 </ul>
	 </section>
<!-- End of Header Banner -->