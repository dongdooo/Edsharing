<!-- Start of Header -->
	<header>
  <!-- Start Main Header -->
  <section class="top_bar">
	<section class="container-fluid container">
		<section class="row-fluid">
			<article class="span6">
				<ul class="details">
					<li><i class="icon-map-marker"> </i> SSP Tower 10, Bangkok, Thailand</li>
					<li><i class="icon-mobile-phone"> </i> +66 82 88 6624</li>
					<li><i class="icon-envelope-alt"> </i> info@bebest.ml</li>
				</ul>
			</article>
			<article class="span4 offset2"> 		
				<ul class="social">
					<li> <a href="#" class="s8"> Pintrest</a> </li>
					<li> <a href="#" class="s7"> Youtube</a> </li>
					<li> <a href="#" class="s6"> Vimeo </a> </li>
					<li> <a href="#" class="s5"> Twitter</a> </li>
					<li> <a href="#" class="s4"> RSS </a> </li>
					<li> <a href="#" class="s3"> Flicker</a> </li>
					<li> <a href="#" class="s2"> Dribble</a> </li>
					<li> <a href="#" class="s1"> Facebook</a> </li>
				</ul>
			</article>
		</section>
	</section>	
  </section>

  <section class="logo_container">
		  <section class="container-fluid container">
				<section class="row-fluid">
					  <section class="span4">
							<h1 id="logo">
								<a href="index.php">
									<img src="images/logo1.png">
								</a>
							</h1>
						</section>
						
						<section class="span5 pull-right">
								<figure class="charity_counter_wrapper">
										<section class="span5">
										<div class="charity_title">
										Be Our Best<br /> Students in 2016
										</div>
										</section>
										<section class="span1 event_more pull-right"> <a href="listing.php"  data-placement="bottom" rel="tooltip" title="View Event Detail" > <i class="icon">+</i>  </a> </section>
										<section class="span6 counter_bg pull-right">
										<div id="countdown162" class="tCountdown">
	 									</div>
										</section>
										
								</figure>
						</section>
						
				</section>
			</section>
  </section>
<?php require_once('nav.php');?>	 
	 </header>
<!-- End of Header -->