	<!-- Main Nav Bar -->
			<nav id="nav">
				<section class="container-fluid container">
					<section class="row-fluid">
			  <div class="navbar navbar-inverse">
				<div class="navbar-inner">
				  <button type="button" class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				  <div class="nav-collapse collapse">
					<ul class="nav">
	
					<li class="active"> <a href="index.php"> Home </a> </li>
					  <li class="dropdown"> <a class="dropdown-toggle" href="about-us.html">  About<b class="caret"></b> </a>
						<ul class="dropdown-menu">
							<li><a href="#"> Organizers</a></li>
							<li><a href="#">Careers</a></li>
						</ul>
					  </li>
 
					  <li class="dropdown"> <a class="dropdown-toggle" href="#"> Talent Events <b class="caret"></b> </a>
						<ul class="dropdown-menu">
							<li><a href="#">Event Detail</a></li>
							<li><a href="#">Event Calander</a></li>
							<li><a href="#">Event Venue</a></li>
						</ul>
					  </li>
 
					  <li class="dropdown"> <a class="dropdown-toggle" href="listing.php" >  Top Ranking Students<b class="caret"></b> </a>
						<ul class="dropdown-menu">
							<li><a href="listing.php">Talent Listings</a></li>
							<li><a href="detail.php">Talent Details</a></li>
							<li><a href="paypal.php">Package Donation </a></li>
						</ul>
					  </li>

 
						<li> <a href="contact_us.php"> Contact </a> </li>
					</ul>
				  </div>
				  <!--/.nav-collapse -->
				</div>
				<!-- /.navbar-inner -->
			  </div>
			  <div class="nav_search pull-right"> <form method="post" actoion="#"> <input type="text" value="Search Here..." name="s" id="s" /> <button><i class="icon-search"></i> </button></form></div>
			  <!-- /.navbar -->
					</section>
				</section>
			</nav>
	<!-- End Main Nav Bar -->